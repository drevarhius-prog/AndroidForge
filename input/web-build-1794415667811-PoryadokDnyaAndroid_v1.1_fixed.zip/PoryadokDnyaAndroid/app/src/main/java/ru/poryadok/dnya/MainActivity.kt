package ru.poryadok.dnya

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingBackup = "[]"
    private val createBackupRequest = 4101
    private val openBackupRequest = 4102

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        ReminderReceiver.createChannel(this)
        requestNotificationPermission()

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.WHITE)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AppBridge(), "AndroidApp")
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = true
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4100)
        }
    }

    inner class AppBridge {
        @JavascriptInterface fun getSavedTasks(): String = getSharedPreferences("tasks", MODE_PRIVATE).getString("json", "") ?: ""
        @JavascriptInterface fun saveTasks(json: String) {
            getSharedPreferences("tasks", MODE_PRIVATE).edit().putString("json", json).apply()
            ReminderScheduler.sync(this@MainActivity, json)
        }
        @JavascriptInterface fun exportBackup(json: String) {
            pendingBackup = json
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "PoryadokDnya-backup.json")
                }
                startActivityForResult(intent, createBackupRequest)
            }
        }
        @JavascriptInterface fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, openBackupRequest)
            }
        }
    }

    @Deprecated("Legacy activity result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        try {
            if (requestCode == createBackupRequest) {
                contentResolver.openOutputStream(uri)?.use { it.write(pendingBackup.toByteArray(Charsets.UTF_8)) }
            } else if (requestCode == openBackupRequest) {
                val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return
                val arr = JSONArray(json)
                getSharedPreferences("tasks", MODE_PRIVATE).edit().putString("json", arr.toString()).apply()
                ReminderScheduler.sync(this, arr.toString())
                webView.evaluateJavascript("window.onNativeBackupLoaded && window.onNativeBackupLoaded(${JSONObject.quote(arr.toString())})", null)
            }
        } catch (_: Exception) {
            webView.evaluateJavascript("window.onNativeBackupError && window.onNativeBackupError()", null)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}
