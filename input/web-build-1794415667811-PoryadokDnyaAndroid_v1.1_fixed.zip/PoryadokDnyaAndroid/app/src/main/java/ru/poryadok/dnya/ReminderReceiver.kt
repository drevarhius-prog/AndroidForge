package ru.poryadok.dnya

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val title = intent.getStringExtra("title") ?: "Напоминание"
        createChannel(context)
        val open = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val content = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, CHANNEL_ID)
            else android.app.Notification.Builder(context).setPriority(android.app.Notification.PRIORITY_HIGH)
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Порядок дня").setContentText(title)
            .setStyle(android.app.Notification.BigTextStyle().bigText(title))
            .setAutoCancel(true).setContentIntent(content).build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            manager.notify(id, notification)
        }
    }
    companion object {
        const val CHANNEL_ID = "task_reminders"
        fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val channel = NotificationChannel(CHANNEL_ID, "Напоминания о заданиях", NotificationManager.IMPORTANCE_HIGH).apply { description = "Уведомления по времени заданий"; enableVibration(true) }
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
            }
        }
    }
}

object ReminderScheduler {
    fun sync(context: Context, json: String) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        try {
            val prefs = context.getSharedPreferences("scheduled_reminders", Context.MODE_PRIVATE)
            val previous = prefs.getStringSet("ids", emptySet()) ?: emptySet()
            previous.forEach { old ->
                val oldId = old.toIntOrNull() ?: return@forEach
                val oldPi = PendingIntent.getBroadcast(context, oldId, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                alarm.cancel(oldPi)
            }
            val activeIds = mutableSetOf<String>()
            val items = JSONArray(json)
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val idText = item.optString("id")
                val id = idText.hashCode() and 0x7fffffff
                val at = item.optLong("at", 0L)
                val done = item.optBoolean("done", false)
                val fired = item.optBoolean("fired", false)
                val intent = Intent(context, ReminderReceiver::class.java).putExtra("id", id).putExtra("title", item.optString("t", "Напоминание"))
                val pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                if (at > now && !done && !fired) {
                    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    activeIds.add(id.toString())
                } else alarm.cancel(pi)
            }
            prefs.edit().putStringSet("ids", activeIds).apply()
        } catch (_: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val json = context.getSharedPreferences("tasks", Context.MODE_PRIVATE).getString("json", "[]") ?: "[]"
            ReminderScheduler.sync(context, json)
        }
    }
}
