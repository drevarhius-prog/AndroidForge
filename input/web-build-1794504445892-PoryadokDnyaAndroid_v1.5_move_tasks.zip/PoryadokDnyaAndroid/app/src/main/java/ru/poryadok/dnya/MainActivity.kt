package ru.poryadok.dnya

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingBackup = "[]"
    private var pendingSoundTaskId = ""
    private val createBackupRequest = 4101
    private val openBackupRequest = 4102
    private val pickTaskSoundRequest = 4104

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        ReminderReceiver.createDefaultChannel(this)
        val notificationPermissionNeeded = Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        requestNotificationPermission()
        if (!notificationPermissionNeeded) requestExactAlarmAccess()

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.WHITE)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AppBridge(), "AndroidApp")
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = true
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            val saved = getSharedPreferences("tasks", MODE_PRIVATE).getString("json", "[]") ?: "[]"
            ReminderScheduler.sync(this, saved)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4100)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4100) requestExactAlarmAccess()
    }

    private fun requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= 31) {
            val alarm = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            if (!alarm.canScheduleExactAlarms()) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:$packageName")))
                } catch (_: Exception) { }
            }
        }
    }

    inner class AppBridge {
        @JavascriptInterface fun getSavedTasks(): String = getSharedPreferences("tasks", MODE_PRIVATE).getString("json", "") ?: ""
        @JavascriptInterface fun saveTasks(json: String) {
            getSharedPreferences("tasks", MODE_PRIVATE).edit().putString("json", json).apply()
            ReminderScheduler.sync(this@MainActivity, json)
        }
        @JavascriptInterface fun exportBackup(json: String) {
            pendingBackup = json
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "PoryadokDnya-backup.json")
                }
                startActivityForResult(intent, createBackupRequest)
            }
        }
        @JavascriptInterface fun pickTaskSound(taskId: String) {
            pendingSoundTaskId = taskId
            runOnUiThread {
                val existing = try {
                    val json = getSharedPreferences("tasks", MODE_PRIVATE).getString("json", "") ?: ""
                    findTaskSound(json, taskId)
                } catch (_: Exception) { null }
                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Звук уведомления для задания")
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, Settings.System.DEFAULT_NOTIFICATION_URI)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing ?: Settings.System.DEFAULT_NOTIFICATION_URI)
                }
                startActivityForResult(intent, pickTaskSoundRequest)
            }
        }
        @JavascriptInterface fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, openBackupRequest)
            }
        }
    }

    private fun findTaskSound(json: String, taskId: String): Uri? {
        val root = JSONObject(json)
        val days = root.optJSONObject("days") ?: return null
        val keys = days.keys()
        while (keys.hasNext()) {
            val arr = days.optJSONArray(keys.next()) ?: continue
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                if (item.optString("id") == taskId) {
                    val raw = item.optString("soundUri", "")
                    if (raw.isNotBlank()) return Uri.parse(raw)
                }
            }
        }
        return null
    }

    @Deprecated("Legacy activity result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        try {
            if (requestCode == pickTaskSoundRequest) {
                val picked = data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                    ?: Settings.System.DEFAULT_NOTIFICATION_URI
                val ringtone = RingtoneManager.getRingtone(this, picked)
                val name = try { ringtone?.getTitle(this) ?: "Стандартный звук телефона" } catch (_: Exception) { "Стандартный звук телефона" }
                ReminderReceiver.createChannel(this, picked)
                webView.evaluateJavascript(
                    "window.onTaskSoundSelected && window.onTaskSoundSelected(${JSONObject.quote(pendingSoundTaskId)}, ${JSONObject.quote(picked.toString())}, ${JSONObject.quote(name)})",
                    null
                )
            } else if (data.data != null) {
                val uri = data.data!!
                if (requestCode == createBackupRequest) {
                    contentResolver.openOutputStream(uri)?.use { it.write(pendingBackup.toByteArray(Charsets.UTF_8)) }
                } else if (requestCode == openBackupRequest) {
                    val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return
                    val arr = JSONArray(json)
                    getSharedPreferences("tasks", MODE_PRIVATE).edit().putString("json", arr.toString()).apply()
                    ReminderScheduler.sync(this, arr.toString())
                    webView.evaluateJavascript("window.onNativeBackupLoaded && window.onNativeBackupLoaded(${JSONObject.quote(arr.toString())})", null)
                }
            }
        } catch (_: Exception) {
            webView.evaluateJavascript("window.onNativeBackupError && window.onNativeBackupError()", null)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}
