package ru.poryadok.dnya

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val title = intent.getStringExtra("title") ?: "Напоминание"
        val soundRaw = intent.getStringExtra("soundUri")
        val sound = try { if (soundRaw.isNullOrBlank()) Settings.System.DEFAULT_NOTIFICATION_URI else Uri.parse(soundRaw) } catch (_: Exception) { Settings.System.DEFAULT_NOTIFICATION_URI }
        createChannel(context, sound)
        val open = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val content = open?.let { PendingIntent.getActivity(context, id, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE) }
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, channelId(sound))
            else android.app.Notification.Builder(context).setPriority(android.app.Notification.PRIORITY_MAX)
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Порядок дня").setContentText(title)
            .setStyle(android.app.Notification.BigTextStyle().bigText(title))
            .setAutoCancel(true).setShowWhen(true)
            .apply { if (content != null) setContentIntent(content) }
            .apply {
                if (Build.VERSION.SDK_INT < 26) {
                    setSound(sound)
                    setVibrate(longArrayOf(0, 250, 120, 250))
                }
            }.build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            manager.notify(id, notification)
        }
    }

    companion object {
        private const val CHANNEL_PREFIX = "task_reminders_"
        fun channelId(sound: Uri?): String = CHANNEL_PREFIX + ((sound?.toString() ?: "default").hashCode().toUInt().toString(16))
        fun createDefaultChannel(context: Context) = createChannel(context, Settings.System.DEFAULT_NOTIFICATION_URI)
        fun createChannel(context: Context, sound: Uri?) {
            if (Build.VERSION.SDK_INT >= 26) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val soundUri = sound ?: Settings.System.DEFAULT_NOTIFICATION_URI
                val id = channelId(soundUri)
                val channel = NotificationChannel(id, "Напоминания о заданиях", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Звуковые уведомления по времени заданий"
                    enableVibration(true)
                    setSound(soundUri, AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                }
                manager.createNotificationChannel(channel)
            }
        }
    }
}

object ReminderScheduler {
    fun sync(context: Context, json: String) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        try {
            val prefs = context.getSharedPreferences("scheduled_reminders", Context.MODE_PRIVATE)
            val previous = prefs.getStringSet("ids", emptySet()) ?: emptySet()
            previous.forEach { old ->
                val oldId = old.toIntOrNull() ?: return@forEach
                val oldPi = PendingIntent.getBroadcast(context, oldId, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                alarm.cancel(oldPi)
            }
            val activeIds = mutableSetOf<String>()
            val root = JSONObject(json)
            val days = root.optJSONObject("days")
            if (days != null) {
                val dayKeys = days.keys()
                while (dayKeys.hasNext()) {
                    val dateKey = dayKeys.next()
                    val tasks = days.optJSONArray(dateKey) ?: continue
                    scheduleArray(context, alarm, tasks, dateKey, now, activeIds)
                }
            } else if (json.trim().startsWith("[")) {
                scheduleArray(context, alarm, JSONArray(json), "legacy", now, activeIds)
            }
            prefs.edit().putStringSet("ids", activeIds).apply()
        } catch (_: Exception) { }
    }

    private fun scheduleArray(context: Context, alarm: AlarmManager, items: JSONArray, dateKey: String,
                              now: Long, activeIds: MutableSet<String>) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val idText = dateKey + ":" + item.optString("id")
            val id = idText.hashCode() and 0x7fffffff
            val at = item.optLong("at", 0L)
            val done = item.optBoolean("done", false)
            val fired = item.optBoolean("fired", false)
            val soundUri = item.optString("soundUri", "")
            val intent = Intent(context, ReminderReceiver::class.java)
                .putExtra("id", id)
                .putExtra("title", item.optString("t", "Напоминание"))
                .putExtra("soundUri", soundUri)
            val pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (at > now && !done && !fired) {
                try {
                    if (Build.VERSION.SDK_INT >= 31) {
                        if (alarm.canScheduleExactAlarms()) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                        else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    } else if (Build.VERSION.SDK_INT >= 23) {
                        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    } else {
                        alarm.setExact(AlarmManager.RTC_WAKEUP, at, pi)
                    }
                } catch (_: SecurityException) {
                    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
                activeIds.add(id.toString())
            } else alarm.cancel(pi)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderReceiver.createDefaultChannel(context)
            val json = context.getSharedPreferences("tasks", Context.MODE_PRIVATE).getString("json", "[]") ?: "[]"
            ReminderScheduler.sync(context, json)
        }
    }
}
