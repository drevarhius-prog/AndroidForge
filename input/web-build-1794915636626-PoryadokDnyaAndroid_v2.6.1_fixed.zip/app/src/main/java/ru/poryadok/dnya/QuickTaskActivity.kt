package ru.poryadok.dnya

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class QuickTaskActivity : Activity() {
    private lateinit var taskInput: EditText
    private lateinit var timeButton: Button
    private var reminderAt: Long? = null
    private val voiceRequest = 5201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        ReminderReceiver.createDefaultChannel(this)
        requestNotificationPermissionIfNeeded()

        val padding = dp(24)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, dp(28), padding, padding)
            gravity = Gravity.TOP
        }

        val title = TextView(this).apply {
            text = "Новое задание"
            textSize = 24f
            setTextColor(0xFF202124.toInt())
        }
        layout.addView(title, matchWrap())

        taskInput = EditText(this).apply {
            hint = "Название задания"
            textSize = 17f
            isSingleLine = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val inputParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(20) }
        layout.addView(taskInput, inputParams)

        val voiceButton = Button(this).apply {
            text = "Сказать название голосом"
            setOnClickListener { startVoiceInput() }
        }
        val voiceParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        layout.addView(voiceButton, voiceParams)

        val reminderLabel = TextView(this).apply {
            text = "Время напоминания"
            textSize = 16f
            setTextColor(0xFF202124.toInt())
        }
        val labelParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) }
        layout.addView(reminderLabel, labelParams)

        timeButton = Button(this).apply {
            text = "Выбрать время"
            setOnClickListener { chooseTime() }
        }
        val timeParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        layout.addView(timeButton, timeParams)

        val saveButton = Button(this).apply {
            text = "Добавить"
            setOnClickListener { saveTaskAndClose() }
        }
        val saveParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(28) }
        layout.addView(saveButton, saveParams)

        setContentView(layout)
        taskInput.requestFocus()
    }

    private fun startVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите название задания")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            startActivityForResult(intent, voiceRequest)
        } catch (_: Exception) {
            Toast.makeText(this, "Голосовой ввод недоступен", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseTime() {
        val initial = Calendar.getInstance().apply {
            if (reminderAt != null) timeInMillis = reminderAt!!
            else add(Calendar.HOUR_OF_DAY, 1)
        }
        TimePickerDialog(
            this,
            { _, hour, minute ->
                val selected = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                reminderAt = selected.timeInMillis
                timeButton.text = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
            },
            initial.get(Calendar.HOUR_OF_DAY),
            initial.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun saveTaskAndClose() {
        val title = taskInput.text.toString().trim()
        if (title.isEmpty()) {
            taskInput.error = "Введите название задания"
            taskInput.requestFocus()
            return
        }
        val at = reminderAt
        if (at != null && at <= System.currentTimeMillis()) {
            Toast.makeText(this, "Выберите время в будущем", Toast.LENGTH_LONG).show()
            return
        }

        try {
            val prefs = getSharedPreferences("tasks", MODE_PRIVATE)
            val raw = prefs.getString("json", "[]") ?: "[]"
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val root: JSONObject
            if (raw.trim().startsWith("{")) {
                root = JSONObject(raw)
            } else {
                root = JSONObject().put("version", 2).put("days", JSONObject().put(today, JSONArray(raw)))
            }
            val days = root.optJSONObject("days") ?: JSONObject()
            val todayTasks = days.optJSONArray(today) ?: JSONArray()
            val task = JSONObject()
                .put("id", UUID.randomUUID().toString())
                .put("t", title)
                .put("done", false)
                .put("at", at ?: JSONObject.NULL)
                .put("fired", false)
                .put("ex", false)
            todayTasks.put(task)
            days.put(today, todayTasks)
            root.put("version", 2)
            root.put("days", days)

            val saved = root.toString()
            prefs.edit().putString("json", saved).apply()
            ReminderScheduler.sync(this, saved)
            Toast.makeText(this, "Задание добавлено", Toast.LENGTH_SHORT).show()
            finish()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось сохранить задание", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5200)
            return
        }
        requestExactAlarmAccessIfNeeded()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 5200) requestExactAlarmAccessIfNeeded()
    }

    private fun requestExactAlarmAccessIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val alarm = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            if (!alarm.canScheduleExactAlarms()) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        .setData(Uri.parse("package:$packageName")))
                } catch (_: Exception) { }
            }
        }
    }

    @Deprecated("Legacy activity result API for Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val recognized = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull().orEmpty()
            if (recognized.isNotBlank()) taskInput.setText(recognized)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
