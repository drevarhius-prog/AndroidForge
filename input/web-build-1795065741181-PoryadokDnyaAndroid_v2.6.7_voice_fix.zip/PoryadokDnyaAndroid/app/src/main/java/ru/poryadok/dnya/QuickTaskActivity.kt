package ru.poryadok.dnya

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.speech.RecognizerIntent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Quick task screen opened from the launcher's long-press shortcut. */
class QuickTaskActivity : Activity() {
    private lateinit var taskInput: EditText
    private lateinit var reminderButton: Button
    private var reminderHour: Int? = null
    private var reminderMinute: Int? = null

    companion object {
        private const val VOICE_REQUEST = 4201
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        ReminderReceiver.createDefaultChannel(this)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setFillViewport(true)
            setBackgroundColor(Color.rgb(247, 248, 252))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            gravity = Gravity.TOP
        }
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val heading = TextView(this).apply {
            text = "Новое задание"
            textSize = 25f
            setTextColor(Color.rgb(25, 35, 55))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(heading, matchWrap())

        taskInput = EditText(this).apply {
            hint = "Название задания"
            textSize = 17f
            setTextColor(Color.rgb(25, 35, 55))
            setHintTextColor(Color.rgb(125, 135, 150))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(Color.WHITE, Color.rgb(220, 225, 235))
        }
        val inputParams = matchWrap().apply { topMargin = dp(24) }
        content.addView(taskInput, inputParams)

        val voiceButton = makeButton("🎙  Создать задание", false)
        content.addView(voiceButton, buttonParams(18))
        voiceButton.setOnClickListener { startVoiceInput() }

        reminderButton = makeButton("Время напоминания: не выбрано", false)
        content.addView(reminderButton, buttonParams(18))
        reminderButton.setOnClickListener { chooseReminderTime() }

        val saveButton = makeButton("Сохранить задание", true)
        content.addView(saveButton, buttonParams(24))
        saveButton.setOnClickListener { saveTask() }

        setContentView(scroll)
    }

    private fun startVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Надиктуйте название задания")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            startActivityForResult(intent, VOICE_REQUEST)
        } catch (_: Exception) {
            Toast.makeText(this, "Голосовой ввод недоступен. Проверьте приложение распознавания речи.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Legacy activity result API supports a wide range of Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != VOICE_REQUEST || resultCode != RESULT_OK || data == null) return
        val recognized = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if (recognized.isNotBlank()) {
            taskInput.setText(recognized)
            taskInput.setSelection(taskInput.text.length)
        }
    }

    private fun chooseReminderTime() {
        val now = Calendar.getInstance()
        val initialHour = reminderHour ?: now.get(Calendar.HOUR_OF_DAY)
        val initialMinute = reminderMinute ?: now.get(Calendar.MINUTE)
        TimePickerDialog(this, { _, hour, minute ->
            reminderHour = hour
            reminderMinute = minute
            reminderButton.text = String.format(Locale.getDefault(), "Время напоминания: %02d:%02d", hour, minute)
        }, initialHour, initialMinute, true).apply {
            setButton(TimePickerDialog.BUTTON_NEUTRAL, "Без напоминания") { _, _ ->
                reminderHour = null
                reminderMinute = null
                reminderButton.text = "Время напоминания: не выбрано"
            }
            show()
        }
    }

    private fun saveTask() {
        val title = taskInput.text.toString().trim()
        if (title.isEmpty()) {
            taskInput.error = "Введите название задания"
            taskInput.requestFocus()
            return
        }

        val now = System.currentTimeMillis()
        var reminderAt: Long? = null
        if (reminderHour != null && reminderMinute != null) {
            val reminder = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, reminderHour!!)
                set(Calendar.MINUTE, reminderMinute!!)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (reminder.timeInMillis <= now) {
                Toast.makeText(this, "Выберите время напоминания в будущем", Toast.LENGTH_LONG).show()
                return
            }
            reminderAt = reminder.timeInMillis
        }

        try {
            val prefs = getSharedPreferences("tasks", MODE_PRIVATE)
            val raw = prefs.getString("json", "") ?: ""
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val root: JSONObject
            val days: JSONObject

            if (raw.trim().startsWith("{")) {
                root = JSONObject(raw)
                days = root.optJSONObject("days") ?: JSONObject().also { root.put("days", it) }
            } else {
                root = JSONObject().put("version", 2)
                days = JSONObject()
                if (raw.trim().startsWith("[")) {
                    try { days.put(today, JSONArray(raw)) } catch (_: Exception) { }
                }
                root.put("days", days)
            }

            val todayTasks = days.optJSONArray(today) ?: JSONArray().also { days.put(today, it) }
            val task = JSONObject()
                .put("id", UUID.randomUUID().toString())
                .put("t", title)
                .put("done", false)
                .put("at", reminderAt ?: JSONObject.NULL)
                .put("fired", false)
                .put("ex", false)
            todayTasks.put(task)
            root.put("version", 2)
            root.put("days", days)

            val savedJson = root.toString()
            prefs.edit().putString("json", savedJson).commit().also { if (!it) throw IllegalStateException("Не удалось записать список заданий") }
            ReminderScheduler.sync(this, savedJson)

            val keyboard = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            keyboard.hideSoftInputFromWindow(taskInput.windowToken, 0)
            Toast.makeText(this, "Задание сохранено", Toast.LENGTH_SHORT).show()
            finishAndRemoveTask()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось сохранить задание", Toast.LENGTH_LONG).show()
        }
    }

    private fun makeButton(label: String, primary: Boolean): Button = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        minHeight = dp(52)
        setTextColor(if (primary) Color.WHITE else Color.rgb(35, 55, 85))
        background = roundedBackground(
            if (primary) Color.rgb(37, 99, 235) else Color.WHITE,
            if (primary) Color.rgb(37, 99, 235) else Color.rgb(220, 225, 235)
        )
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun roundedBackground(fill: Int, stroke: Int): android.graphics.drawable.Drawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(13).toFloat()
            setStroke(dp(1), stroke)
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun buttonParams(top: Int) = matchWrap().apply { topMargin = dp(top) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
